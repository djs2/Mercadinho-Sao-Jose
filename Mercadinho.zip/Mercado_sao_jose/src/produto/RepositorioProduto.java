package produto;

public interface RepositorioProduto {

	void inserir(Produto produto) throws ProdutoJaCadastradoException;

	Produto procurar(String tipo) throws ProdutoNaoEncontradoException;

	void atualizar(Produto produto) throws ProdutoNaoEncontradoException;

	void remover(String tipo) throws ProdutoNaoEncontradoException;

	boolean existe(String tipo) throws ProdutoNaoEncontradoException;
}
