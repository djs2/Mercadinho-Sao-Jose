package produto;

import pessoa.Funcionario;

//Classe b�sica de Produto

public class Produto {
	private String nome;
	private String tipo;
	private double preco;
	private String codigo;
	private String fornecedor;
	private Funcionario funcionario;

	public Produto(String nome, String tipo, double preco, String fornecedor, String codigo, Funcionario funcionario) {
		this.nome = nome;
		this.tipo = tipo;
		this.preco = preco;
		this.codigo = codigo;
		this.fornecedor = fornecedor;
		this.funcionario = funcionario;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipo() {
		return this.tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public double getPreco() {
		return this.preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public String getCodigo() {
		return this.codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getFornecedor() {
		return this.fornecedor;
	}

	public void setFornecedor(String fornecedor) {
		this.fornecedor = fornecedor;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

}