package produto;

//Cole��o de neg�cio

public class CadastroProduto {
	
	private RepositorioProduto repProduto;

public CadastroProduto(RepositorioProduto repProduto)	{
	this.repProduto = repProduto;
}
	
	
	public void cadastrar(Produto produto) throws ProdutoJaCadastradoException, ProdutoNaoEncontradoException {
		if (!(this.repProduto.existe(produto.getCodigo()))) {
			this.repProduto.inserir(produto);
		} else {
			throw new ProdutoJaCadastradoException();
		}
	}

	public Produto procurar(String nome) throws ProdutoNaoEncontradoException {
		if (this.repProduto.existe(nome)) {
			return repProduto.procurar(nome);
		} else {
			throw new ProdutoNaoEncontradoException();
		}

	}

	public void atualizar(Produto produto) throws ProdutoNaoEncontradoException {
		if (this.repProduto.existe(produto.getCodigo())) {
			this.repProduto.atualizar(produto);
		} else {
			throw new ProdutoNaoEncontradoException();
		}
	}

	public void remover(Produto produto) throws ProdutoNaoEncontradoException {

		if (this.repProduto.existe(produto.getCodigo())) {
			this.repProduto.remover(produto.getCodigo());
		} else {
			throw new ProdutoNaoEncontradoException();
		}
	}


	public void validar(Produto produto) throws ProdutoNaoEncontradoException {

		if (!produto.getCodigo().matches("[0-9]{13}")) {
			throw new ProdutoNaoEncontradoException();
		
		}
	}

}