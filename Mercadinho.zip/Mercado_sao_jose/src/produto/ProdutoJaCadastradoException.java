package produto;

public class ProdutoJaCadastradoException extends Exception {
	public ProdutoJaCadastradoException() {
		super("Produto j� cadastrado");
	}
}