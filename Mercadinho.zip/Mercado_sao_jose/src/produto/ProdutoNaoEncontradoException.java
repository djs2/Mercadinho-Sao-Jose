package produto;

public class ProdutoNaoEncontradoException extends Exception {
	public ProdutoNaoEncontradoException() {
		super("O Produto pesquisado n�o foi encontrado.");
	}
}
