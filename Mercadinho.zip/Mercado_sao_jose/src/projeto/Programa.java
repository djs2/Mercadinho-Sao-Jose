package projeto;

import pessoa.CPFInvalidoException;
import pessoa.Cliente;
import pessoa.DataInvalidaException;
import pessoa.Funcionario;
import pessoa.PessoaJaCadastradaException;
import pessoa.PessoaNaoEncontradaException;
import pessoa.RepositorioPessoas;
import pessoa.RepositorioPessoasArray;
import produto.Produto;
import produto.ProdutoJaCadastradoException;
import produto.ProdutoNaoEncontradoException;
import produto.RepositorioProduto;

public class Programa {

	public static void main(String[] args)
			throws PessoaNaoEncontradaException, CPFInvalidoException, DataInvalidaException {

		Cliente cliente1 = null;
		Produto produto1 = null;

		RepositorioPessoas repPessoa = null;
		RepositorioProduto produto = null;

		repPessoa = new RepositorioPessoasArray();
		Fachada fachada = null;

		fachada = new Fachada(repPessoa, produto);

		try {
			cliente1 = new Cliente("01358146443", "Eduardo", "10118999", "Rua Dona Lindu", "55555-555", "Dinheiro");
			fachada.cadastroPessoa(cliente1);

			System.out.println(fachada.imprimirPessoa(cliente1.getCpf()));

		} catch (PessoaNaoEncontradaException e) {
			System.out.println(e.getMessage());
		} catch (PessoaJaCadastradaException e) {
			System.out.println(e.getMessage());
		}

		/*
		 * try { produto1 = new Produto("Feij�o", "Comida", 6.99, "0541237451269",
		 * "Da casa", null); fachada.cadastroProduto(produto1);
		 * 
		 * System.out.println(fachada.imprimirProduto(produto1.getCodigo()));
		 * 
		 * } catch (ProdutoNaoEncontradoException e) {
		 * System.out.println(e.getMessage()); } catch (ProdutoJaCadastradoException e)
		 * { System.out.println(e.getMessage()); }
		 * 
		 * }
		 */
	}
}