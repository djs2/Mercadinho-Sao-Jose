package projeto;

import pessoa.CPFInvalidoException;
import pessoa.CadastroPessoas;
import pessoa.DataInvalidaException;
import pessoa.Pessoa;
import pessoa.PessoaJaCadastradaException;
import pessoa.PessoaNaoEncontradaException;
import pessoa.RepositorioPessoas;
import produto.CadastroProduto;
import produto.Produto;
import produto.ProdutoJaCadastradoException;
import produto.ProdutoNaoEncontradoException;
import produto.RepositorioProduto;

public class Fachada {

	private CadastroPessoas cadastroPessoa;
	private CadastroProduto cadastroProduto;

	public Fachada(RepositorioPessoas repPessoa, RepositorioProduto repProduto) {
		this.cadastroPessoa = new CadastroPessoas(repPessoa);
		this.cadastroProduto = new CadastroProduto(repProduto);
	}

	public void cadastroPessoa(Pessoa pessoa) throws PessoaNaoEncontradaException, PessoaJaCadastradaException,
			CPFInvalidoException, DataInvalidaException {
		this.cadastroPessoa.cadastrar(pessoa);

	}

	public void cadastroProduto(Produto produto) throws ProdutoJaCadastradoException, ProdutoNaoEncontradoException {
		this.cadastroProduto.cadastrar(produto);
	}

	public void removerPessoa(String cpf) throws PessoaJaCadastradaException, PessoaNaoEncontradaException {
		this.cadastroPessoa.remover(cpf);

	}

	public void removerProduto(Produto produto) throws ProdutoNaoEncontradoException, ProdutoNaoEncontradoException  {
		this.cadastroProduto.remover(produto);
	}

	public boolean procurarPessoa(String cpf) throws PessoaNaoEncontradaException, PessoaJaCadastradaException {
		this.cadastroPessoa.procurar(cpf);

		return false;
	}

	public Produto procurarProduto(String codigo) throws ProdutoNaoEncontradoException, ProdutoNaoEncontradoException  {
		return this.cadastroProduto.procurar(codigo);
	}

	public void atualizarPessoa(Pessoa pessoa) throws PessoaJaCadastradaException, PessoaNaoEncontradaException {
		this.cadastroPessoa.atualizar(pessoa);
	}

	public void atualizarProduto(Produto produto) throws ProdutoNaoEncontradoException, ProdutoNaoEncontradoException  {
		this.cadastroProduto.atualizar(produto);
	}

	public String imprimirPessoa(String cpf) throws PessoaNaoEncontradaException, PessoaJaCadastradaException { 
		
		// imprime as informa��es basicas do objeto pessoa
		
		Pessoa pessoa = this.cadastroPessoa.procurar(cpf);

		String print = "Nome: " + pessoa.getNome() + "\nCPF: " + pessoa.getCpf() + "\nEndere�o: " + pessoa.getEndereco()
				+ "\nNascimento: " + pessoa.getDataNascim() + "\nTelefone: " + pessoa.getTelefone();
		return print;

	}

	public String imprimirProduto(String codigo) throws ProdutoNaoEncontradoException, ProdutoJaCadastradoException {

		Produto produto = this.cadastroProduto.procurar(codigo);

		String print = "Nome: " + produto.getNome() + "\nCodigo " + produto.getCodigo() + "\nTipo: " + produto.getTipo()
				+ "\nPre�o: " + produto.getPreco();

		return print;

	}

}
