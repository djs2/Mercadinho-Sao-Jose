package pessoa;

public class Cliente extends Pessoa{
	
	private String tipoPagamento; //Dinheiro, cupom ou cart�o
	
	public Cliente(String nome, String cpf, String dataNascim, String endereco, String telefone, String tipoPagamento) {
		super(nome, cpf, dataNascim, endereco, telefone);
		this.tipoPagamento = tipoPagamento;
	}
	
	

	public String getTipoPagamento() {
		return tipoPagamento;
	}

	public void setTipoPagamento(String tipoPagamento) {
		this.tipoPagamento = tipoPagamento;
	}



	// Metodo abstrato             //Obitem o nome, cpf e endere�o do cliente
	public void obterIdentificador() {
		System.out.println("Cliente identificado como: " + this.getNome() + "\nN� CPF: "+ this.getCpf() + "\nMora :"+ this.getEndereco());                
	}
	
	
}
