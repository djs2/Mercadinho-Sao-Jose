package pessoa;

// INTERFACE NEG�CIO-DADOS QUE VAI SER USADA PELAS CLASSES COLE��O DE DADOS
public interface RepositorioPessoas {

	void inserir(Pessoa pessoa) throws PessoaJaCadastradaException;

	void atualizar(Pessoa pessoa) throws PessoaNaoEncontradaException;

	void remover(String cpf) throws PessoaNaoEncontradaException;

	Pessoa procurar(String cpf) throws PessoaNaoEncontradaException;

	boolean existir(String cpf) throws PessoaNaoEncontradaException;

}
