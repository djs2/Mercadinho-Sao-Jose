package pessoa;

public class RepositorioPessoasArray implements RepositorioPessoas{
	
	private Pessoa[] pessoas;
	private int indice;
	
	// iniciar os atributos do array
	public RepositorioPessoasArray() {
		this.pessoas = new Pessoa[50];
		this.indice = 0;
	}
	
	// inserir pessoa no array
	public void inserir(Pessoa pessoas) {
		if (this.indice < 50) {
			this.pessoas[this.indice] = pessoas;
			this.indice++;
		}
	}
	
	// procurar o atributo para encontrar a pessoa
	public Pessoa procurar(String cpf) {
		Pessoa resposta = null;
		boolean encontrado = false;
		for (int i = 0; i<this.indice && !encontrado; i++) {
			if (this.pessoas[i].getCpf().equals(cpf)) {
				resposta = this.pessoas[i];
				encontrado = true;
			}
		}
		return resposta;
	}
	
	// remover pessoa
	public void remover(String cpf) {
		boolean encontrado = false;
		for (int i=0; i<this.indice && !encontrado; i++) {
			if(this.pessoas[i].getCpf().equals(cpf)) {
				this.indice--;
				this.pessoas[i] = this.pessoas[this.indice];
				this.pessoas[this.indice] = null;
				encontrado = true;
			}
		}
	}
	
	// atualizar pessoa
	public void atualizar(Pessoa pessoa) {
		boolean encontrado = false;
		for (int i = 0; i<this.indice;i++) {
			if (this.pessoas[i].getCpf().equals(pessoa.getCpf())) {
				this.pessoas[i] = pessoa;
				encontrado = true;
			}
		}
	}
	
	// verificando se a pessoa existe
	public boolean existir(String cpf) {
		boolean encontrado = false;
		for (int i=0; i<this.indice && !encontrado; i++) {
			if(this.pessoas[i].getCpf().equals(cpf)) {
				encontrado = true;
			}
		}
		return encontrado;
	}

	
}
