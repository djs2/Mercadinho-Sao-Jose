package pessoa;

public class Funcionario extends Pessoa{
	
	private String cargo; // cargo de ocupa��o
	private double salario;
	private String id; //numero de identifica��o
	
	public Funcionario(String nome, String cpf, String dataNascim, String endereco, String telefone, String cargo, double salario, String id   ) {
		super(nome, cpf, dataNascim, endereco, telefone);
		this.cargo = cargo;
		this.salario = salario;
		this.id = id;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	// Metodo abstrato           //Obitem o nome, cargo e salario do funcionario
	public void obterIdentificador() {
		System.out.println("Funcionario identificado com: "+ this.getNome() + "\n cargo: "+ this.getCargo()+"\nTem salario de R$"+this.getSalario());                
		
	}

}
