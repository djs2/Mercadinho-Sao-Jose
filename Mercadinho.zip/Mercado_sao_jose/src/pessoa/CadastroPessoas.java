package pessoa;
//cole��o de neg�cio
public class CadastroPessoas {

	private RepositorioPessoas repPessoa; 
	
	public CadastroPessoas(RepositorioPessoas repPessoa) {
		this.repPessoa = repPessoa;
	}
	
	public void cadastrar(Pessoa pessoa) throws PessoaJaCadastradaException, PessoaNaoEncontradaException,
	CPFInvalidoException, DataInvalidaException{
		
		if (this.repPessoa.procurar(pessoa.getCpf()) == null) {

			this.validar(pessoa);
			this.repPessoa.inserir(pessoa);
		} else {
			throw new PessoaJaCadastradaException();	
		}
	}
	
	public void atualizar(Pessoa pessoa) throws PessoaNaoEncontradaException, PessoaJaCadastradaException{
		if (this.repPessoa.procurar(pessoa.getCpf()) != null) {
			this.repPessoa.atualizar(pessoa);
		} else {
			throw new PessoaNaoEncontradaException();
		}
	}
	
	public void remover(String cpf) throws PessoaNaoEncontradaException, PessoaJaCadastradaException{
		if (this.repPessoa.procurar(cpf) != null) {
			this.repPessoa.remover(cpf);
		} else {
			throw new PessoaNaoEncontradaException();
		}
	}
	
	public Pessoa procurar(String cpf) throws PessoaNaoEncontradaException, PessoaJaCadastradaException{
		
		Pessoa pessoa = this.repPessoa.procurar(cpf);
		if(pessoa == null) {
			throw new PessoaNaoEncontradaException();
		} else {
			return pessoa;
		}
	}
	
	public void validar(Pessoa pessoa) throws CPFInvalidoException, DataInvalidaException{
		
		if (!pessoa.getCpf().matches("[0-9]{11}")) {
			throw new CPFInvalidoException(pessoa.getCpf());
		}
		
		if (!pessoa.getDataNascim().matches("[0-9]{8}")) {
			throw new DataInvalidaException(pessoa.getDataNascim());
		}
	}
	
}











