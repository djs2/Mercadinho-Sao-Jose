package pessoa;

public class PessoaJaCadastradaException extends Exception {
	
	public PessoaJaCadastradaException () {
		super("Esse Cpf j� est� cadastrado.");
	}

}
