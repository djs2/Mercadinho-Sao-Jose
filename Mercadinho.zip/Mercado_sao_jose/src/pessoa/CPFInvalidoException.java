package pessoa;

public class CPFInvalidoException extends Exception {
	
	public CPFInvalidoException (String cpf) {
		super ("CPF: " + cpf + " est� fora do padr�o. Note que, no CPF DEVE conter apenas n�mero e OBRIGAT�RIAMENTE 11 d�gitos.");
	}

}
