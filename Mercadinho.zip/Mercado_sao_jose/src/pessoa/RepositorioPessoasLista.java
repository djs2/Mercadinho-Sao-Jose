package pessoa;

public class RepositorioPessoasLista implements RepositorioPessoas{

	///////
	/////
	//////////
	////////
	///////
	
	private Pessoa pessoa;
	private RepositorioPessoasLista next;
	
	public RepositorioPessoasLista() {
		this.pessoa = null;
		this.next = null;
	}
	
	public void inserir(Pessoa pessoa) throws PessoaJaCadastradaException {
		if (this.pessoa == null) {
			this.pessoa = pessoa;
			this.next = new RepositorioPessoasLista();
		} else {
			this.next.inserir(pessoa);
		}
		
	}

	
	public void atualizar(Pessoa pessoa) throws PessoaNaoEncontradaException {
		if (this.pessoa.getCpf().equals(pessoa.getCpf())) {
			this.pessoa = pessoa;
		} else {
			this.next.atualizar(pessoa);
		}
		
	}

	
	public void remover(String cpf) throws PessoaNaoEncontradaException {
		if (this.pessoa.getCpf().equals(cpf)) {
			this.pessoa = this.next.pessoa;
			this.next = this.next.next;
		} else {
			this.next.remover(cpf);
		}
		
	}

	
	public Pessoa procurar(String cpf) throws PessoaNaoEncontradaException {
		Pessoa pessoa;   //////////////////////////////
		if (this.next == null) {
			pessoa = null;
		} else if (this.pessoa.getCpf().equals(cpf)) {
			pessoa = this.pessoa;
		} else {
			pessoa = this.next.procurar(cpf);
		}
		return pessoa;
	}

	
	public boolean existir(String cpf) {
		boolean encontrado = false;
		if(this.pessoa.getCpf().equals(cpf)) {
			encontrado = true;
		} else {
			this.next.existir(cpf);
		}
		return encontrado;
	}

}
