package pessoa;

public class DataInvalidaException extends Exception{
	
	public DataInvalidaException (String data) {
		super (data + " est� fora do padr�o. Note que o formato deve ser dd/mm/aaaa, onde: "
				+ "\n'dd' coresponde a dia"
				+ "\n'mm' corresponde a m�s"
				+ "\n'aaaa' corresponde a ano");
	}

}
