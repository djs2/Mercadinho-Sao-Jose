package pessoa;

public class PessoaNaoEncontradaException extends Exception{
	
	public PessoaNaoEncontradaException() {
		super("N�o existe pessoa com este cpf cadastrado no sistema.");
	}

}
