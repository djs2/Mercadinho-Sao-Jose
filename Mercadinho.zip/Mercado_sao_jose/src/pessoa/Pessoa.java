package pessoa;

public abstract class Pessoa {
	
	private String cpf;
	private String nome;
	private String dataNascim;
	private String endereco;
	private String telefone;
	
	public Pessoa(String cpf, String nome, String dataNascim, String endereco, String telefone) {
		this.cpf = cpf;
		this.nome = nome;
		this.dataNascim = dataNascim;
		this.endereco = endereco;
		this.telefone = telefone;
		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getDataNascim() {
		return dataNascim;
	}

	public void setDataNascim(String dataNascim) {
		this.dataNascim = dataNascim;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
	// Metodo abstrato
	public abstract void obterIdentificador();
	
	
}
